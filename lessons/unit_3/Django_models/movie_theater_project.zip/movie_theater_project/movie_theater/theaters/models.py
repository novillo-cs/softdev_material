from django.db import models
#from django.contrib.gis.db import models as gismodels

# Create your models here.
class Theater(models.Model):
    # 'Theater verbose_name is a human-readable name for the field
    name = models.CharField(
        'Theater name',
        max_length=200,
        unique=True,
    )
    address1 = models.CharField(
        "Address line 1",
        max_length=400,
    )
    address2 = models.CharField(
        "Address line 2",
        max_length=400,
        null=True, blank=True
    )
    zip_code = models.CharField(
        "ZIP / Postal code",
        max_length=8,
    )
    city = models.CharField(
        "City",
        max_length=100,
    )
    state = models.CharField(
        "State",
        max_length=2,
    )

class Screen(models.Model):
    # we cannot delete a theater if there is a screen associated to it
    theater = models.ForeignKey(Theater, on_delete=models.PROTECT)
    name = models.CharField(max_length=30)
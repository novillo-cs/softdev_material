from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView
from django.urls import reverse_lazy
from django.contrib import messages

from .models import Actor, Movie

# Create your views here.

class ActorListView(ListView):
    model = Actor

class ActorCreateView(CreateView):
    model = Actor
    fields = ['name']

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.add_message(
            self.request, messages.SUCCESS,
            'Actor "{actor_name}" has been created'.format(
                actor_name=self.object.name))
        return response

    def get_success_url(self):
    	return reverse_lazy("movies:actor_detail", args=[self.object.id])

class ActorDetailView(DetailView):
    model = Actor
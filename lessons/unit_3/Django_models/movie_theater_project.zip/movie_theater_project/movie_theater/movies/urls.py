from django.urls import path

from . import views

app_name = "movies"

urlpatterns = [
    path("actors/", views.ActorListView.as_view(), name="actor_list"),
    path("actors/<int:pk>", views.ActorDetailView.as_view(), name="actor_detail"),
    path("actors/new", views.ActorCreateView.as_view(), name="actor_create"),
    path("actors/update/<int:pk>", views.ActorUpdateView.as_view(),
         name="actor_update"),
    path("actors/delete/<int:pk>", views.ActorDeleteView.as_view(),
         name="actor_delete"),
    path("movies/", views.MovieListView.as_view(), name="movie_list"),
    path("movies/new", views.MovieCreateView.as_view(), name="movie_create"),
    path("movies/<int:pk>", views.MovieDetailView.as_view(),
         name="movie_detail"),
    path("movies/update/<int:pk>", views.MovieUpdateView.as_view(),
         name="movie_update"),
    path("movies/delete/<int:pk>", views.MovieDeleteView.as_view(),
         name="movie_delete"),
]

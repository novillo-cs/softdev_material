from django.urls import path

from . import views

app_name = "movies"

urlpatterns = [
    path("actors/", views.ActorListView.as_view(), name="actor_list"),
    path("actors/<int:pk>", views.ActorDetailView.as_view(), name="actor_detail"),
    path("actors/new", views.ActorCreateView.as_view(), name="actor_create"),
]
